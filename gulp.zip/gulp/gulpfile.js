const gulp = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const imagemin = require('gulp-imagemin');
const uglify = require('gulp-uglify');

const paths = {
  styles: { src: 'src/scss/**/*.scss', dest: 'dist/css/' },
  scripts: { src: 'src/js/**/*.js', dest: 'dist/js/' },
  images: { src: 'src/images/**/*', dest: 'dist/images/' }
};

function compileSass() {
  return gulp.src(paths.styles.src)
    .pipe(sass({ outputStyle: 'compressed' }).on('error', sass.logError))
    .pipe(gulp.dest(paths.styles.dest));
}

function compressImages() {
  return gulp.src(paths.images.src)
    .pipe(imagemin())
    .pipe(gulp.dest(paths.images.dest));
}

function minifyJs() {
  return gulp.src(paths.scripts.src)
    .pipe(uglify())
    .pipe(gulp.dest(paths.scripts.dest));
}

function watchFiles() {
  gulp.watch(paths.styles.src, compileSass);
  gulp.watch(paths.scripts.src, minifyJs);
  gulp.watch(paths.images.src, compressImages);
}

exports.default = gulp.series(gulp.parallel(compileSass, minifyJs, compressImages), watchFiles);
