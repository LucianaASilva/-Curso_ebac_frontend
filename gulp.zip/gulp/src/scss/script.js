document.addEventListener("DOMContentLoaded", () => {
  console.log("JavaScript carregado e minificado com sucesso!");
  
  const header = document.querySelector("header");
  if (header) {
    header.addEventListener("click", () => {
      alert("Você clicou no header!");
    });
  }
});
